<!DOCTYPE html>

<html lang="en">

<head>
	<style>
		ol li {
			color: green;
			font-size: 1rem;
			padding: 2px;
			list-style-type: none;
		}

		ul li {
			color: black;
			font-size: 0.9rem;
			padding: 1px;
			margin-top: 10px;
			list-style-type: none;
		}
li a{
			color:whitesmoke;
			cursor:pointer;
			decoration:none;
		}
		a:active{
			color:white;
		}
	</style>
</head>

<?php
  include('header2.php');
  ?>

<body>


	<!-- Navbar
    ================================================== -->
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
<li class="dropdown" style="list-style-type:none; margin-top:2vh;">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Select Logine Page <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
 
              
              <li>
                  <a target="_blank" href="index.php">Organizer</a>
              </li>
 
              <li>
                <a target="_blank" href="selection.php">Judge</a>
              </li>
              
              
                    </ul>
                    </li>
					<li style="list-style-type:none; float:right;margin-top:-2vh;">
					
				<a href="#" data-toggle="modal" data-target="#about-modal">
					<font size="2">DEJS Guidance</font>
				</a>
					</li><br>

			</div>
		</div>
	</div>


	<header class="subhead"style="background-color:#92A9BD;color:whitesmoke;widith:auto;margin-top:2vh;">
		<div class="container">
			<h2>Digital Event Judging System</h2>
			<p class="lead"><b>Ready to serve you...</b></p>
		</div>
	</header>



	<div class="container">



		<!-- About EJS Modal -->
		<div class="modal fade" id="about-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
			<div class="modal-dialog modal-sm">

				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="Login">
							<center>Digital Event Judging System Usage Guidance</center>
						</h4>
					</div>
					<div class="modal-body">

						<ol>
							<li>Organizers:
								<ul>
									<li>Create an account to access this System</li>
									<li>Login into the system</li>
									<li>A complete Your profile in Organizer Settings</li>
									<li>Perform your Activities in judging processes</li>
									<li>Log out</li>
								</ul>
							</li>

							<li>Judges:
								<ul>
									<li>Login in with your code on user selection page</li>
									<li>Perform your Activities in judging processes</li>
									<li>Logout</li>
								</ul>
							</li>

							<li>Contestants:
								<ul>
								<li>Create an account to access this System</li>
									<li>Login into the system</li>
									<li>Chech the event and Apply it</li>
									<li>Chech your Marks</li>
									<li>Log out</li>
								</ul>
							</li>

						</ol>
						<hr />
						<center>
					
									<strong>Digital Event Judging System &COPY;
										<?= date("Y") ?>
									</strong>
						</center>
						<hr />
						<p class="text-center text-muted">
							<button class="btn btn-default" data-dismiss="modal" aria-hidden="true">
								<strong>Close</strong>
							</button>
						</p>

					</div>
				</div>
			</div>
		</div>
		<!-- END About EJS Modal -->



		<form method="POST" action="contestant_connect_login.php">
			<br />
			<table cellpadding="10" cellspacing="0" border="0" align="center">
				<thead>
					<th align="center" style="background-color: #6A8CAF; text-indent: 7px; color: white; ">
						<h4>CONTESTANTS LOGIN</h4>
					</th>
				</thead>

				<tr style="background-color: #b0c7de;">

					<td>


						<h5>
							<i class="icon-user"></i> USERNAME:</h5>
						<input style="font-size: large; height: 35px !important; text-indent: 7px !important;" class="form-control btn-block" type="text"
						 name="username" placeholder="Username" required="true" autofocus="true" />

						<h5>
							<i class="icon-lock"></i> PASSWORD:</h5>
						<input style="font-size: large; height: 35px !important; text-indent: 7px !important;" class="form-control btn-block" type="password"
						 name="password" placeholder="Password" required="true" autofocus="true" />
						<br />
						<center><button style="width: 60% !important;" type="submit" class="btn btn-primary">
							<i class="icon-ok"></i>
							<strong>LOGIN</strong>
						</button></center>
						<br>
						<a href="#"><strong>I forgot password?.</a>
						</strong>
						

					</td>
				</tr>

			</table>

		</form>

	</div>



	<!-- Placed at the end of the document so the pages load faster -->

	<script src="assets/js/jquery.js"></script>
	<script src="assets/js/bootstrap-transition.js"></script>
	<script src="assets/js/bootstrap-alert.js"></script>
	<script src="assets/js/bootstrap-modal.js"></script>
	<script src="assets/js/bootstrap-dropdown.js"></script>
	<script src="assets/js/bootstrap-scrollspy.js"></script>
	<script src="assets/js/bootstrap-tab.js"></script>
	<script src="assets/js/bootstrap-tooltip.js"></script>
	<script src="assets/js/bootstrap-popover.js"></script>
	<script src="assets/js/bootstrap-button.js"></script>
	<script src="assets/js/bootstrap-collapse.js"></script>
	<script src="assets/js/bootstrap-carousel.js"></script>
	<script src="assets/js/bootstrap-typeahead.js"></script>
	<script src="assets/js/bootstrap-affix.js"></script>
	<script src="assets/js/holder/holder.js"></script>
	<script src="assets/js/google-code-prettify/prettify.js"></script>
	<script src="assets/js/application.js"></script>

</body>

</html>