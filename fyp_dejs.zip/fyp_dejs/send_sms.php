<?php



require 'vendor/autoload.php';

use AfricasTalking\SDK\AfricasTalking;

$username = 'jean123';
$apiKey = '1c3b1512971e0eaeb91a3838adcf0b3b7955b966fb9553b38f0f5bc1c7317b51';

$AT = new AfricasTalking($username, $apiKey);

// Create an instance of the SMS service
$sms = $AT->sms();

try {
    $result = $sms->send([
        'to' => '+250781035751',
        'message' => 'Hello'
    ]);

    print_r($result);
} catch (GuzzleHttp\Exception\ClientException $e) {
    echo $e->getMessage();
}
?>