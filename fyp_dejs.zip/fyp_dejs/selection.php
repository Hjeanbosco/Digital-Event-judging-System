 

<!DOCTYPE html>
<html lang="en">
  
  <?php 
  include('header2.php');
    include('session.php');
  ?>

 
 <head>
	<style>
		ol li {
			color: green;
			font-size: 1rem;
			padding: 2px;
			list-style-type: none;
		}

		ul li {
			color: black;
			font-size: 0.9rem;
			padding: 1px;
			margin-top: 10px;
			list-style-type: none;
		}
li a{
			color:whitesmoke;
			cursor:pointer;
			decoration:none;
		}
		a:active{
			color:white;
		}
	</style>
</head>

<?php
  include('header2.php');
  ?>

<body>


	<!-- Navbar
    ================================================== -->
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container">
<li class="dropdown" style="list-style-type:none; margin-top:2vh;">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Select Logine Page <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
 
              
              <li>
                  <a target="_blank" href="index.php">Organizer</a>
              </li>
 
              <li>
              <a target="_blank" href="event_list.php">Contestant</a>
              </li>
              
              
                    </ul>
                    </li>
					<li style="list-style-type:none; float:right;margin-top:-2vh;">
					
				<a href="#" data-toggle="modal" data-target="#about-modal">
					<font size="2">DEJS Guidance</font>
				</a>
					</li><br>

			</div>
		</div>
	</div>
	<!-- About EJS Modal -->
    <div class="modal fade" id="about-modal" tabindex="-1" role="dialog" aria-labelledby="Login" aria-hidden="true">
			<div class="modal-dialog modal-sm">

				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title" id="Login">
							<center>Digital Event Judging System Guidance</center>
						</h4>
					</div>
					<div class="modal-body">

						<ol>
							<li>Organizers:
								<ul>
									<li>Create an account to access this System</li>
									<li>Login into the system</li>
									<li>A complete Your profile in Organizer Settings</li>
									<li>Perform your Activities in judging processes</li>
									<li>Log out</li>
								</ul>
							</li>

							<li>Judges:
								<ul>
									<li>Login in with your code on user selection page</li>
									<li>Perform your Activities in judging processes</li>
									<li>Logout</li>
								</ul>
							</li>

							<li>Contestants:
								<ul>
								<li>Create an account to access this System</li>
									<li>Login into the system</li>
									<li>Chech the event and Apply it</li>
									<li>Chech your Marks</li>
									<li>Log out</li>
								</ul>
							</li>

						</ol>
						<hr />
						<center>
					
									<strong>Digital Event Judging System &COPY;
										<?= date("Y") ?>
									</strong>
						</center>
						<hr />
						<p class="text-center text-muted">
							<button class="btn btn-default" data-dismiss="modal" aria-hidden="true">
								<strong>Close</strong>
							</button>
						</p>

					</div>
				</div>
			</div>
		</div>

	<header class="subhead"style="background-color:#92A9BD;color:whitesmoke;widith:auto;margin-top:2vh;">
		<div class="container">
			<h2>Digital Event Judging System</h2>
			<p class="lead"><b>Ready to serve you...</b></p>
		</div>
	</header>
 
 <div class="container">
 <br><br>
 <hr />
 
 <div id="myGroup">

    
      
             <button class="btn btn-info" data-toggle="collapse" data-target="#judge" data-parent="#myGroup"><i class="icon-chevron-right"></i> <strong>JUDGE</strong></button>  
                                            
         
           
            <div style="border: 0px;" class="accordion-group">
 
                <br /> 
 
              <div class="collapse indent" id="contenstant">
              
             
                  <?php 
    $ame_query = $conn->query("SELECT * FROM main_event WHERE organizer_id = '$session_id' AND status='activated'");
    
            if($ame_query->rowCount()<=0)
            { ?>
             
               <div class="alert alert-warning"><h3><strong>NO ACTIVE EVENT</strong></h3></div>
            <?php }
            else
            {
                $ase_query = $conn->query("SELECT * FROM sub_event WHERE organizer_id = '$session_id' AND status='activated'");
                if($ase_query->rowCount()<=0)
            { ?>
            
                <div class="alert alert-warning"><h3><strong>NO ACTIVE SUB-EVENT</strong></h3></div>
           <?php }
            else
            {
                
            ?>
 
    
            
                
            <?php } } ?>
                
              </div>
              
              
           
           
     
            </div>
            
            
</div>




             
   <!-- codes for judges          
              -->
             
             
              <div class="collapse indent" id="judge">
             
                  <?php 
    $ame_query = $conn->query("SELECT * FROM main_event WHERE organizer_id = '$session_id' AND status='activated'");
    
            if($ame_query->rowCount()<=0)
            { ?>
             
               <div class="alert alert-warning"><h3><strong>NO ACTIVE EVENT</strong></h3></div>
            <?php }
            else
            {
                $ase_query = $conn->query("SELECT * FROM sub_event WHERE organizer_id = '$session_id' AND status='activated'");
                if($ase_query->rowCount()<=0)
            { ?>
            
                <div class="alert alert-warning"><h3><strong>NO ACTIVE SUB-EVENT</strong></h3></div>
           <?php }
            else
            {
                
            ?>
 
      
       <div class="input-group">
       <div class="alert alert-success alert-judge-login">
      <form method="POST" action="judge_profile.php" >
            <h4>Judge's Code</h4>
            <br />
          <input id="myinputJC" style="font-size: large; height: 45px !important;" class="form-control btn-block" name="judge_code" type="password" placeholder="Enter Judge's Code" />
            <p><input style="padding-top: 0px !important; margin-top: 0px !important;" type="checkbox" onclick="myfunctionJC()"/> <strong>Show Code</strong></p>
                                    
                                    
                                    <script>
                                    function myfunctionJC() {
                                        var x = document.getElementById("myinputJC");
                                        if (x.type === "password") {
                                            x.type = "text";
                                        } else {
                                            x.type = "password";
                                        }
                                    }
                                    </script>
       
       <div class="pull-right">
         <button class="btn btn-default" type="reset"><i class="icon-ban-circle"></i> <strong>CLEAR</strong></button>&nbsp;
         <button name="org_panel" class="btn btn-primary" title="Click to proceed to Judging Panel"><i class="icon-ok"></i> <strong>LOGIN</strong></button>
     </div>
 
 
 </form>
        <br />
           </div>   
           
           
    </div> 
    
            
                
            <?php } } ?>
                
              </div>
              
              
           
           
     
            </div>
            
            
</div>
<br><br><br><br><hr/>

 <?php include"footer.php"?>
 
</div>
 
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>
    <script src="assets/js/holder/holder.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>
    <script src="assets/js/application.js"></script>
 

  </body>
</html>
