
<!DOCTYPE html>
<html lang="en">

    <?php 
    include('header.php');
    ?>

  <body>
    <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
       
            
        </div>
      </div>
    </div>
<header class="jumbotron subhead" style="background-color:#92A9BD;color:whitesmoke;height:28vh;">
  <div class="container">
    <h2><b>Contestant Account Registration Form</b></h2>
    <p class="lead"><b>Digital Event Judging System</b></p>
  </div>
</header>
    <div class="container">


  <div class="col-lg-3">
 
  </div>
  <div class="col-lg-6">
 <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Event Contestants Registration Form</h3>
            </div>
            <div class="panel-body">
            
   <form method="POST">
   
   
        
       
        
    <table align="center">
    <tr><td colspan="5"><strong>Basic Information</strong><hr /></td></tr>
    <tr>
    <td>
    Firstname:<b style="font-size:20px;color:red;">*</b>
    <input type="text" name="fname" class="form-control" placeholder="Firstname" aria-describedby="basic-addon1" required autofocus>
 </td>
    <td>&nbsp;</td>
    <td>
    Lastname:<b style="font-size:20px;color:white;">.</b>
    <input type="text" name="lname" class="form-control" placeholder="Lastname" aria-describedby="basic-addon1">
     </td>
    <td>&nbsp;</td>
    <td>
    Email:<b style="font-size:20px;color:red;">*</b>
    <input type="email" name="email" class="form-control" placeholder="Email" aria-describedby="basic-addon1">
 </td>
    </tr>
    
    
     <tr><td colspan="5">&nbsp;</td></tr>
     <tr><td colspan="5"><strong>Account Security</strong><hr /></td></tr>
     <tr>
    <td>
    Username:<b style="font-size:20px;color:red;">*</b>
    <input type="text" name="username" class="form-control" placeholder="Username" aria-describedby="basic-addon1" required autofocus>
 </td>
    <td>&nbsp;</td>
    <td>
    Password:<b style="font-size:20px;color:red;">*</b>
    <input id="password" type="password" name="password" class="form-control" placeholder="Password" aria-describedby="basic-addon1" required="true" autofocus="true" />
 </td>
    <td>&nbsp;</td>
    <td>
    Re-type Password:<b style="font-size:20px;color:red;">*</b>
    <input id="confirm_password" type="password" name="password2" class="form-control" placeholder="Re-type Password" aria-describedby="basic-addon1" required="true" autofocus="true" />
    <!-- <input name="rand_code" type="hidden" value="<?php echo randomcode(); ?>" /> -->
 </td>
    </tr>
    
    <tr>
    <td colspan="4">&nbsp;</td>
    <td><span id='message'></span></td>
    </tr>
    
    
    </table>
 <br />
       <div class="btn-group pull-right">
  <a href="contestant_login.php" type="button" class="btn btn-default">Cancel</a>
  <button name="register" type="submit" class="btn btn-primary">Register</button>
   </form>
</div>
 
    
            </div>
          </div>
  </div>
  <div class="col-lg-3">
 
  </div>
 
          </div>
          
    <!-- Footer
    ================================================== -->
    <footer class="footer">
      <div class="container">
 
        <font size="2" class="pull-left"><strong>Digital Event Judging System &middot; &COPY; <?= date ("Y") ?></strong> </font> <br />
       
      </div>
    </footer>      
   


    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>
    <script src="javascript/jquery1102.min.js"></script>
    
    
    
     <script>
 
    $('#password, #confirm_password').on('keyup', function () {
      if ($('#password').val() == $('#confirm_password').val()) {
        $('#message').html('Matching').css('color', 'green');
      } else 
        $('#message').html('Not Matching').css('color', 'red');
    });
    
    </script>


  </body>
</html>

<?php 
function randomcode() {
$var = "abcdefghijkmnopqrstuvwxyz0123456789";
srand((double)microtime()*1000000);
$i = 0;
$code = '' ;
while ($i <= 5) {
$num = rand() % 33;
$tmp = substr($var, $num, 1);
$code = $code . $tmp;
$i++;
}
return $code;
}
?>


<?php 

if(isset($_POST['register']))
{
 
   $fname=$_POST['fname'];  
   $lname=$_POST['lname'];  
   $email=$_POST['email'];  
   $username=$_POST['username'];  
   $password=$_POST['password'];  
   $password2=$_POST['password2']; 
  
 if($password==$password2)
 {
  $conn->query("insert into contestants(fname,lname,email,username,password)values('$fname','$lname','$email','$username','$password')");

 ?>
<script>
			                                      
			      								window.location = 'contestant_login.php';
			      							   	alert('Contestant <?php echo $fname." ".$lname; ?> registered successfully!');						
			      								</script>
<?php  
 }
 else
 {
  ?>
<script>
 
			      							   	alert('Contestant <?php echo $fname." ".$mname; ?> registration cannot be done. Password and Re-typed password did not match.');						
			      								</script>
<?php  
 }
 
} ?>

 
