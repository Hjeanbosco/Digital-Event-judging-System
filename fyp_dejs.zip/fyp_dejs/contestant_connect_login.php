<?php
session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    // Make sure to establish a database connection first
    $con = mysqli_connect("localhost", "root", "", "dejs_db");

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Use prepared statements to prevent SQL injection
    $query = "SELECT * FROM contestants WHERE username=? AND password=?";
    $stmt = $con->prepare($query);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Check if a matching user was found
    if ($result->num_rows == 1) {
        if ($row["type"] == "user") {
            $_SESSION["username"] = $username;
            echo "<script type='text/javascript'>alert('$username, you are welcome.');window.location='Contestant_apply_panel.php'</script>";
        } else {
            echo "<script type='text/javascript'>alert('Failed to login, invalid username or password.');window.location='contestant_login.php'</script>";
        }
    } else {
        echo "<script type='text/javascript'>alert('Failed to login, invalid username or password.');window.location='contestant_login.php'</script>";
    }

    mysqli_close($con);
}
?>
