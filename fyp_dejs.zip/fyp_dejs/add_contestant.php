 

<!DOCTYPE html>
<html lang="en">
  
  <?php 
  include('header.php');
    include('session.php');
    
    
    $sub_event_id=$_GET['sub_event_id'];
    $se_name=$_GET['se_name'];
     
     
  ?>
  
  <body>
    <!-- Navbar
    ================================================== -->
 
  <header class="subhead"style="background-color:#92A9BD;color:whitesmoke;">
  <div class="container">
    <h2>Welcome to Register Account</h2>
    <p class="lead"><b>Digital Event Judging System</b></p>
  </div>
</header>
<hr />
                
                

   <form method="POST">
   <input value="<?php echo $sub_event_id; ?>" name="sub_event_id" type="hidden" />
 <input value="<?php echo $se_name; ?>" name="se_name" type="hidden" />
 
  
   
   
   
   <table align="center" style="width: 40% !important;">
 <tr>
 <td>
 

 <div style="width: 100% !important;" class="panel panel-primary">
 
 
            <div class="panel-heading">
              <h3 class="panel-title">Register Account To Apply Now</h3>
            </div>
 
 


 
     <div class="panel-body">
 
   <table align="center">
  
 
   <tr>
    
   <td>
   
   <select name="contestant_ctr" class="form-control" style="display:none;">
   
   
                    <?php 
                    
                    $n1=0;
                    
                    while($n1<12)
                    { 
                        $n1++;
                     
                    
                    $cont_query = $conn->query("SELECT * FROM contestants WHERE contestant_ctr='$n1' AND subevent_id='$sub_event_id'") or die(mysql_error());
                   
            
                    if($cont_query->rowCount()>0)
                    {
                        
                    }
                    else
                    {
                        echo "<option>".$n1."</option>";
                    }
                      
                    } 
                    
                    ?>
                    
                    
    
   </select></td>
 
   <td style="padding:2vh;">

      <input name="rand_code" type="hidden" class="form-control" value="<?php echo randomcode();?>" /></td>
   
   <td>
    
    </tr>
<tr>
<td></td>
<td style="padding:2vh;">
    <strong>Enter Your Email:</strong> <br />
    
   <input name="email" placeholder="Enter Your valid Email" type="email" class="form-control" required="true" /></td>
  
   
   <td>
    <strong>Username:</strong> <br />
    
   <input name="username" placeholder="Enter your UserName" type="text" class="form-control" required="true" /></td>
 </td>
   
    </tr>
    <tr>
<td></td>
<td style="padding:2vh;">
    <strong>Enter Your Password:</strong> <br />
    <input id="password" type="password" name="password" class="form-control" placeholder="Password" aria-describedby="basic-addon1" required="true" autofocus="true" /> 
   </td>
  
   
   <td>
    <strong> Re-type Password:</strong> <br />
    <input id="confirm_password" type="password" name="password2" class="form-control" placeholder="Re-type Password" aria-describedby="basic-addon1" required="true" autofocus="true" />
   
   </td>
   <td>
    <input type="hidden" name="type" value="user"class="form-control" aria-describedby="basic-addon1" autofocus="true" />
   
   </td>
    </tr>


        <tr>
<td></td>
<td style="padding:2vh;">
   
   
   <td><center>
   <span id='message'></span></center>
      </td>
      <tr>
      <td>
     <br>
      </td>
    </tr>
  <tr>
 
  <td colspan="3" align="left"><a href="contestant_login.php?sub_event_id=<?php echo $sub_event_id;?>&se_name=<?php echo $se_name;?>" class="btn btn-default" style="margin-left:30vh;">Already Have Account!!!!</a>
  <button name="add_contestant" class="btn btn-primary">Register</button></td>
  </tr>
  
  </table>
 </form>
</div>
 
 
    <script src="javascript/jquery1102.min.js"></script>
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>

         <script>
 
 $('#password, #confirm_password').on('keyup', function () {
   if ($('#password').val() == $('#confirm_password').val()) {
     $('#message').html('Matching').css('color', 'green');
   } else 
     $('#message').html('Not Matching').css('color', 'red');
 });
 
 </script>
  </body>
  </html>

  <?php 
function randomcode() {
$var = "abcdefghijkmnopqrstuvwxyz0123456789";
srand((double)microtime()*1000000);
$i = 0;
$code = '' ;
while ($i <= 5) {
$num = rand() % 33;
$tmp = substr($var, $num, 1);
$code = $code . $tmp;
$i++;
}
return $code;
}
?>

<?php
if(isset($_POST['add_contestant']))
{
    
    $se_name=$_POST['se_name'];
    $sub_event_id=$_POST['sub_event_id'];
    $contestant_ctr=$_POST['contestant_ctr'];
     $email=$_POST['email'];
     $username=$_POST['username'];
     $password=$_POST['password'];
     $rand_code=$_POST['rand_code'];
     $password2=$_POST['password2']; 
     $type=$_POST['type'];

     if($password==$password2)
     {
      $conn->query("insert into contestants(email,username,password,subevent_id,contestant_ctr,rand_code,type)values('$email','$username','$password','$sub_event_id','$contestant_ctr','$rand_code','$type')");
    
     ?>
    <script>
                                                
                                window.location = 'contestant_login.php';
                                   alert('Contestant <?php echo $username; ?> registered successfully!');						
                                </script>
    <?php  
     }
     else
     {
      ?>
    <script>
     
                                   alert('Contestant <?php echo $username;?> registration cannot be done. Password and Re-typed password did not match.');						
                                </script>
    <?php  
     }
     
    } ?>
 
 
