<?php
include('dbcon.php');
// Process form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $contestant_id = $_POST["contestant_id"];
    $TotalScore = $_POST["TotalScore"];

    // Write an SQL query to update data in the database
    $sql = "UPDATE contestants SET TotalScore=$TotalScore WHERE contestant_id=$contestant_id"; // Update with your table name and column names

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    if ($stmt->execute()) {
        echo"<script type='text/javascript'>alert('Marks $TotalScore succeessfly updated!!.');window.location='view.php'</script>";
    } else {
        echo"<script type='text/javascript'>alert('Marks $TotalScore failed to be updated!!.');window.location='view.php'</script>";
   
    }
}
?>
