  <!-- Footer
    ================================================== -->
    <footer class="footer">
      <div class="container">
      <center>
      
      <font size="4">Digital Event Judging System &COPY; <?= date('Y') ?>, All Right Reserved!!!.</font>
   
      
      
      </center>
      
      </div>
    </footer>