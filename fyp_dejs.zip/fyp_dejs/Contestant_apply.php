<!DOCTYPE html>
<html lang="en">

<?php 
 
 include('header2.php');
    include('session.php');
    error_reporting(1);
    
    $sub_event_id=$_GET['sub_event_id'];
    $se_name=$_GET['se_name'];
    
 ?>
 <?php

if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    // You can now display $username on the dashboard
}?>

<body data-spy="scroll" data-target=".bs-docs-sidebar">

     <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="brand" href="#"><img src="uploads/<?php echo $company_logo; ?>" width="23" height="23" />&nbsp; <font size="3">Digital Event Judging System</font></a> 
 
          <div class="nav-collapse collapse">
            <ul class="nav">

              <li>
                <a href="contestant_panel.php">View Your Identifications</a>
              </li>
 
                <li>
                <a href="event_list.php"><strong>LIST OF EVENTS</strong></a>
              </li>
 
              
 
              <li>
                <a href="contestant_login.php">Logout</a>
              </li>
          
            </ul>
          </div>
        </div>
      </div>
    </div>
  <header class="subhead"style="background-color:#92A9BD;color:whitesmoke;">
  <div class="container">
    <h2><?php echo $se_name; ?> Settings</h2>
    <p class="lead"><b>Digital Event Judging System</b></p>
  </div>
</header>


  <div class="container">
    <div class="span12">
      <br />
      <div class="col-md-12">
        <ul class="breadcrumb">

           <a href="#">Welcome To DEJS</a> / </li>

          <li><a href="event_list.php">List of Events</a> / </li>

          <li>
            <?php echo $se_name; ?> Settings
          </li>

        </ul>
      </div>




      <form method="POST">
        <input value="<?php echo $sub_event_id; ?>" name="sub_event_id" type="hidden" />


        <hr />

        <div id="myGroup">

          <a class="btn btn-info" style="margin-bottom: 4px !important;" data-toggle="collapse" data-target="#criteria"
            data-parent="#myGroup"><i class="icon-chevron-right"></i> <strong>SUB-EVENT CRITERIA</strong></a>

  <a class="btn btn-info" style="margin-bottom: 4px !important;" data-toggle="collapse" data-target="#contestant"
            data-parent="#myGroup"><i class="icon-chevron-right"></i> <strong>Apply Now if Your Interested</strong></a>

          <div style="border: 0px;" class="accordion-group">

            <div class="collapse indent" id="contestant">


              <section id="download-bootstrap">
                <div class="page-header">
                <h1> 
                

   <form method="POST">
   <input value="<?php echo $sub_event_id; ?>" name="sub_event_id" type="hidden" />
 <input value="<?php echo $se_name; ?>" name="se_name" type="hidden" />
 
  
   
 
   
   <table align="center" style="width: 40% !important;">
 <tr>
 <td>
 <div style="width: 100% !important;" class="panel panel-primary">

 <div style="background-color:#92A9BD;color:whitesmoke; border-radius:10px;">
 
            <div class="panel-heading">
              <center><h3 style="background-color:skyblue;border-radius:10px 10px 0px 0px; padding:2vh 2vh 2vh 2vh;">Fill Form To Aplly</h3></center>
            </div>
 

 
     <div class="panel-body">
 
   <table align="center">
  
 
   <tr>
    
   <td>
   <select name="contestant_ctr" class="form-control" style="display:none;">
   
   
                    <?php 
                    
                    $n1=0;
                    
                    while($n1<12)
                    { 
                        $n1++;
                     
                    
                    $cont_query = $conn->query("SELECT * FROM contestants WHERE contestant_ctr='$n1' AND subevent_id='$sub_event_id'") or die(mysql_error());
                   
            
                    if($cont_query->rowCount()>0)
                    {
                        
                    }
                    else
                    {
                        echo "<option>".$n1."</option>";
                    }
                      
                    } 
                    
                    ?>
                    
                    
    
   </select></td>
   <td>&nbsp;&nbsp;&nbsp;</td>
   <td>
    <strong style="font-size:20px;">Enter Your FullNames:</strong><br>
    
   <input name="fullname" placeholder="Enter FullNames" type="text" class="form-control" required="true" style="padding:10px 50px;" /></td>
   </tr>
  <tr>
  <td colspan="3" align="right"><button name="add_contestant" class="btn btn-primary" style="padding:10px 50px 10px 50px;">Apply</button></td>
  </tr>
  <tr><td></td>
   </tr>
<tr><td><hr /></td>
   </tr>

  </table>
 </form>
</div>
 
          </div>
 </td>
 </tr>
 </table> 
              </section>

            </div>
            </div>




    <div class="collapse indent" id="criteria">
      <section id="download-bootstrap">
        <div class="page-header">
          <h1>Criteria's Settings &nbsp;
        </div>
        <table class="table table-bordered">
          <thead>
            <th>No.</th>
            <th>Criteria name</th>
            <th>Percentage</th>
          </thead>
          <form method="POST">
            <tbody>
              <?php    
  $percnt=0;
   	$crit_query = $conn->query("SELECT * FROM criteria WHERE subevent_id='$sub_event_id'") or die(mysql_error());
    while ($crit_row = $crit_query->fetch()) 
        { $percnt=$percnt+$crit_row['percentage'];
            $crit_id=$crit_row['criteria_id'];
            ?>
              <tr>
                <td width="115">
                  <?php echo $crit_row['criteria_ctr']; ?>
                </td>
                <td>
                  <?php echo $crit_row['criteria']; ?>
                </td>
                <td width="15" colspan="2">
                  <?php echo $crit_row['percentage']; ?>
                </td>
              
              </tr>
              <?php } ?>

              <tr>

                <?php
      if($percnt<100)
      { ?>
                <td colspan="3">
                  <div class="alert alert-danger pull-right">

                    <strong>The Total Percentage is under 100%.</strong>
                  </div>
                </td>
                <td colspan="2">
                  <div class="alert alert-danger">

                    <strong>
                      <?php  echo $percnt; ?>%
                    </strong>
                  </div>
                </td>

                <?php } ?>

                <?php
      if($percnt>100)
      { ?>
                <td colspan="3">
                  <div class="alert alert-danger pull-right">

                    <strong>The Total Percentage is over 100%.</strong>
                  </div>
                </td>
                <td colspan="2">
                  <div class="alert alert-danger">

                    <strong>
                      <?php  echo $percnt; ?>%
                    </strong>
                  </div>

                </td>

                <?php } ?>


                <?php
      if($percnt==100)
      { ?>
                <td colspan="2"><strong> TOTAL MARKS:</strong></td>
                <td colspan="3">
                  <span style="font-size: 15px !important;" class="badge badge-info">
                    <?php  echo $percnt; ?> %
                  </span>
                </td>

                <?php } ?>
              </tr>


             
            </tbody>
          </form>
        </table>

      </section>
    </div>


  </div>



  </div>



  </form>
  </div>
  </div>


  <?php 
if (isset($_POST['add_contestant'])) {
    // Validate and sanitize user inputs
    $se_name = $_POST['se_name'];
    $sub_event_id = $_POST['sub_event_id'];
    $fullname = $_POST['fullname'];

    
    // Establish a database connection
    $con = mysqli_connect("localhost", "root", "", "dejs_db");

    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare and execute the SQL update query
    $sql = "UPDATE contestants SET fullname = '$fullname' WHERE username = '$username'". mysqli_connect_error();

    if (mysqli_query($con, $sql)) {
        // Successful update
        echo "<script>
            window.location = 'Contestant_apply.php?sub_event_id=$sub_event_id&se_name=$se_name';
            alert('Thanks $fullname! Your Application has been successfully submitted.');
        </script>";
    } else {
        // Error handling for the database update
        echo "Error In inserting data: " . mysqli_error($con);
    }

    // Close the database connection
    mysqli_close($con);
}
?>

  
  


  <!-- javascript
    ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->

  <script src="assets/js/jquery.js"></script>
  <script src="assets/js/bootstrap-transition.js"></script>
  <script src="assets/js/bootstrap-alert.js"></script>
  <script src="assets/js/bootstrap-modal.js"></script>
  <script src="assets/js/bootstrap-dropdown.js"></script>
  <script src="assets/js/bootstrap-scrollspy.js"></script>
  <script src="assets/js/bootstrap-tab.js"></script>
  <script src="assets/js/bootstrap-tooltip.js"></script>
  <script src="assets/js/bootstrap-popover.js"></script>
  <script src="assets/js/bootstrap-button.js"></script>
  <script src="assets/js/bootstrap-collapse.js"></script>
  <script src="assets/js/bootstrap-carousel.js"></script>
  <script src="assets/js/bootstrap-typeahead.js"></script>
  <script src="assets/js/bootstrap-affix.js"></script>
  <script src="assets/js/holder/holder.js"></script>
  <script src="assets/js/google-code-prettify/prettify.js"></script>
  <script src="assets/js/application.js"></script>

</body>

</html>