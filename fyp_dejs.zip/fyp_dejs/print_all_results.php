<?php
   include('header2.php');
    include('session.php');
    
 $active_main_event=$_GET['main_event_id'];
    ?> 
 
     
<!DOCTYPE html>
<html lang="en">
 
<style style="text/css">
@media print {
    footer {page-break-after: always;}
}
</style>
  <body data-spy="scroll" data-target=".bs-docs-sidebar">
 
 


  <div class="container">

    <!-- Docs nav
    ================================================== -->
    <div class="row">
      
      <div class="span12">



        <!-- Download
        ================================================== -->
        
           <?php   
          $event_query = $conn->query("select * from main_event where mainevent_id='$active_main_event'") or die(mysql_error());
		while ($event_row = $event_query->fetch()) 
        { 
  
  
  
   $s_event_query = $conn->query("select * from sub_event where mainevent_id='$active_main_event'") or die(mysql_error());
		while ($s_event_row = $s_event_query->fetch()) 
        {
            $active_sub_event=$s_event_row['subevent_id'];
            ?>
        
             <center>
             
             
             <?php include('doc_header.php'); ?>
             
             
 
             <table>
        <tr>
             <td align="center">
            <h2><?php echo $event_row['event_name']; ?> - Over All Result</h2> 
             </td>
              </tr>
               <tr>
             <td align="center">
            <h3><?php echo $s_event_row['event_name']; ?></h3> 
             </td>
              </tr>
               
             </table>
             
             </center>
        

          </td>
          <td><center><h3>   <?php
$placingzz_query = $conn->query("SELECT * FROM contestants ORDER BY totalScore DESC") or die(mysqli_error());
$place_title = 0; // Initialize the place_title

echo '<table class="table table-bordered">';
echo '<tr><th>Contestant Names</th><th>Scored Marks</th><th>Ranking</th></tr>';

while ($placingzz_row = $placingzz_query->fetch()) {
    $place_title++; // Increment place_title for each contestant
    echo '<tr>';
    echo '<td>' . $placingzz_row["fullname"] . '</td>';
    echo '<td>' . $placingzz_row["TotalScore"] . '</td>';
    echo '<td>' . $place_title . '</td>';
    echo '</tr>';
}

echo '</table>';
?></h3></center></td>
         </tr>
         
         
 
         
         
        <?php } ?>
        
    
     </tbody>
     
          </table>
          
            <hr />
            <br />
             <table align="center">  
              <tr>
            <?php
            $jjn_result_query = $conn->query("select distinct judge_id from sub_results where mainevent_id='$active_main_event' and subevent_id='$active_sub_event' order by judge_id ASC") or die(mysql_error());
while ($jjn_result_row = $jjn_result_query->fetch()) {
      $jx_id=$jjn_result_row['judge_id'];
      
    $jname_query = $conn->query("select * from judges where judge_id='$jx_id'") or die(mysql_error());
$jname_row = $jname_query->fetch();

    ?>
            <td>&nbsp;&nbsp;
            <table>
            <tr><td align="center">&nbsp;&nbsp;&nbsp;<u><strong><?php echo $jname_row['fullname'];?></strong></u>&nbsp;&nbsp;&nbsp;</td></tr>
             <tr><td align="center">&nbsp;&nbsp;<?php echo $jname_row['jtype'];?> Judge&nbsp;&nbsp;</td></tr>
            </table>
            &nbsp;&nbsp;</td>
    
           
  
<?php }?>
</tr>
</tr>
   </table> 
 
 <footer></footer>
<?php } ?>
<h1>Organizing Committee</h1>
<hr />
<br /><br />
<hr />
     <table align="center">  
              <tr>
           
            <?php
            
            $jjn_result_query = $conn->query("select * from organizer where org_id='$session_id'") or die(mysql_error());
while ($jjn_result_row = $jjn_result_query->fetch()) {
      

    ?>
            <td>
            <table>
            <tr><td align="center">&nbsp;&nbsp;&nbsp;<u><strong><?php echo $jjn_result_row['fname']." ".$jjn_result_row['mname']." ".$jjn_result_row['lname'];?></strong></u>&nbsp;&nbsp;&nbsp;</td></tr>
             <tr><td align="center">Tabulator</td></tr>
            </table>
            </td>
    
           
  
<?php } ?>
</tr>
</table>
<hr />
 <table align="center"> 
 
              <tr>
          <?php
            $jjn_result_query = $conn->query("select * from organizer where organizer_id='$session_id'") or die(mysql_error());
while ($jjn_result_row = $jjn_result_query->fetch()) {
      

    ?>
            <td>
            <table>
            <tr><td align="center">&nbsp;&nbsp;&nbsp;<u><strong><?php echo $jjn_result_row['fname']." ".$jjn_result_row['mname']." ".$jjn_result_row['lname'];?></strong></u>&nbsp;&nbsp;&nbsp;</td></tr>
             <tr><td align="center">Organizer</td></tr>
            </table>
            </td>
    
           
  
<?php } ?>


     
    </div>

  </div>
 
</div>


<?php include('footer.php'); ?>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>

    <script src="assets/js/holder/holder.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>

    <script src="assets/js/application.js"></script>

 

  </body>
</html>