<?php 
include('session.php');

$rand_code=$_POST['rand_code'];

	$query = $conn->query("SELECT * FROM contestants WHERE rand_code='$rand_code'");
			$row = $query->fetch();
			$num_row = $query->rowcount();
            
            
            
            
		if( $num_row > 0 ) { 
		  
          
$contestant_ctr=$row['contestant_ctr'];
$subevent_id=$row['subevent_id'];

?>

            <script>
            
            window.location.href = "contestant_panel.php?contestant_ctr=<?php echo $contestant_ctr; ?>&subevent_id=<?php echo $subevent_id; ?>";
            </script>
<?php }
else
{ ?>

<script>
alert('wrong code');
 			
window.location = 'selection.php';
</script>
    
<?php }
?>


                                                