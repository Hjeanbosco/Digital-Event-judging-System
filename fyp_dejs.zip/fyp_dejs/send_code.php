 

<!DOCTYPE html>
<html lang="en">
  
  <?php 
  include('header.php');
    include('session.php');
    
    
require 'vendor/autoload.php';

use AfricasTalking\SDK\AfricasTalking;

$username = 'jean123';
$apiKey = '1c3b1512971e0eaeb91a3838adcf0b3b7955b966fb9553b38f0f5bc1c7317b51';

$AT = new AfricasTalking($username, $apiKey);

// Create an instance of the SMS service
$sms = $AT->sms();

    $sub_event_id=$_GET['sub_event_id'];
    $se_name=$_GET['se_name'];
    $judge_id=$_GET['judge_id'];
     
  ?>
  
  <body>
    <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
       
            
        </div>
      </div>
    </div>
<header class="jumbotron subhead" id="overview">
  <div class="container">
    <h1><?php echo $se_name; ?> Settings</h1>
    <p class="lead">Digital Event Judging System</p>
  </div>
</header>
    <div class="container">

   <form method="POST">
    <input value="<?php echo $sub_event_id; ?>" name="sub_event_id" type="hidden" />
 <input value="<?php echo $se_name; ?>" name="se_name" type="hidden" />
 <input value="<?php echo $judge_id; ?>" name="judge_id" type="hidden" />
 
  
   <div class="col-lg-3">
   </div>
   <div class="col-lg-6">
 <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title"> Send Judge's Code</h3>
            </div>
 
 


 
     <div class="panel-body">
  
   <table align="center">
  
  
  <?php    
   	$judge_query = $conn->query("SELECT * FROM judges WHERE judge_id='$judge_id'") or die(mysql_error());
    while ($judge_row = $judge_query->fetch()) 
        { ?>
   <tr>
    
   <td>
<br />
   <td>&nbsp;</td>
   <td>
     <br />
   <input name="code" type="hidden" class="form-control" value="<?php echo $judge_row['code']; ?>"/></td>
   <td>&nbsp;</td>
   <td>
    Judge's Phone Number <br />
    <input name="phone" type="text" class="form-control" value="<?php echo $judge_row['phone']; ?>" required/></td>
     
   
   </tr>
  <?php } ?>
  <tr>
  <td colspan="5">&nbsp;</td>
  </tr>
  <tr>
  <td colspan="5" align="right"><a href="sub_event_details_edit.php?sub_event_id=<?php echo $sub_event_id;?>&se_name=<?php echo $se_name;?>" class="btn btn-default">Back</a>&nbsp;<button name="send_code" class="btn btn-success">Send Code</button></td>
  </tr>
  </table>
 
</div>
 
          </div>
          
        
  </div>
  
 <div class="col-lg-3">
   </div>
 
</form>
          </div>
          
          
<?php 

if(isset($_POST['send_code']))
{
    
    $se_name=$_POST['se_name'];
    $sub_event_id=$_POST['sub_event_id'];
    $judge_id=$_POST['judge_id'];
     $phone=$_POST['phone'];
     $code=$_POST['code'];
   /* judges */
   try {
    $result = $sms->send([
        'to' => $phone,
        'message' => 'Hello, Your judge login code: '.$code.',Thank you !!.' // Include the code in the message
    ]);

   
    $conn->query("update judges set phone='$phone' where judge_id='$judge_id'");
    }
    catch (GuzzleHttp\Exception\ClientException $e) {
        echo $e->getMessage();
    }
  
 ?>
<script>
			                                      
			      								window.location = 'sub_event_details_edit.php?sub_event_id=<?php echo $sub_event_id;?>&se_name=<?php echo $se_name;?>';
			      							   	alert(' This <?php echo $code; ?> Sent successfully to <?php echo $phone; ?>');						
			      								</script>
<?php  
 
 
} ?>
  
  
<?php include('footer.php'); ?>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
