            <table>
      
              <tr>
              <td><center><img src="uploads/<?php echo $company_logo; ?>" width="50" height="50" /> </center></td>
             </tr>
             
             <tr>
              <td>
              <center>
              <font size="2"><b>Company Name:</b>&nbsp;&nbsp;<?php echo $company_name; ?></font><br />
                <font size="2"><b>Location:</b>&nbsp;&nbsp;<?php echo $company_address; ?></font> <br />
                <font size="2"><b>Contact:</b>&nbsp;&nbsp;<b>Tel:</b>&nbsp;<?php echo $company_telephone; ?> &middot; 
                
                <b>Email:</b>&nbsp;<?php echo $company_email; ?><br />
                </font>
              </center>
              </td>
              </tr>
          
              </table>