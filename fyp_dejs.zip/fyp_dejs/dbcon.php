<?php
$conn = new PDO('mysql:host=localhost;dbname=dejs_db', 'root', '');
?>
