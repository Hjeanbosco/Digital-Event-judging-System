 
<!DOCTYPE html>
<html lang="en">
   
<?php
   include('header2.php');
    include('session.php');
  $active_sub_event=$_GET['event_id'];
    ?>
    
    
<style style="text/css">
@media print {
    footer {page-break-after: always;}
}
</style>


  <body data-spy="scroll" data-target=".bs-docs-sidebar">
 
 


  <div class="container">

    <!-- Docs nav
    ================================================== -->
    <div class="row">
      
      <div class="span12">



        <!-- Download
        ================================================== -->
        
           <?php   
         
             $s_event_query = $conn->query("select * from sub_event where subevent_id='$active_sub_event'") or die(mysql_error());
		while ($s_event_row = $s_event_query->fetch()) 
        {
            
            
            $MEidxx=$s_event_row['mainevent_id'];
            
              $event_query = $conn->query("select * from main_event where mainevent_id='$MEidxx'") or die(mysql_error());
		while ($event_row = $event_query->fetch()) 
        {
            
            ?>
        
             <center>
             
             
             <?php include('doc_header.php'); ?>
             
             
             <table>
             <tr>
             <td align="center">
            <h4><b>Event:<?php echo $event_row['event_name']; ?>&nbsp;&nbsp;-&nbsp;&nbsp;Sub-Event:<?php echo $s_event_row['event_name'];?></h4> 
            <font size="4"><h3>Over All Result</h3></font>
             </td>
              </tr>
   
               
             </table>
             
             </center>
          <br />
          <?php
$placingzz_query = $conn->query("SELECT * FROM contestants ORDER BY totalScore DESC") or die(mysqli_error());
$place_title = 0; // Initialize the place_title

echo '<table class="table table-bordered">';
echo '<tr><th>Contestant Names</th><th>Scored Marks</th><th>Ranking</th></tr>';

while ($placingzz_row = $placingzz_query->fetch()) {
    $place_title++; // Increment place_title for each contestant
    echo '<tr>';
    echo '<td>' . $placingzz_row["fullname"] . '</td>';
    echo '<td>' . $placingzz_row["TotalScore"] . '</td>';
    echo '<td>' . $place_title . '</td>';
    echo '</tr>';
}

echo '</table>';
?>

<hr />
     <table align="center">  
              <tr>
           
            <?php
            
            $jjn_result_query = $conn->query("select * from organizer where org_id='$session_id'") or die(mysql_error());
while ($jjn_result_row = $jjn_result_query->fetch()) {
      

    ?>
            <td>
            <table>
            <tr><td align="center">&nbsp;&nbsp;&nbsp;<u><strong><?php echo $jjn_result_row['fname']." ".$jjn_result_row['mname']." ".$jjn_result_row['lname'];?></strong></u>&nbsp;&nbsp;&nbsp;</td></tr>
             <tr><td align="center">Tabulator</td></tr>
            </table>
            </td>
    
           
  
<?php } ?>
</tr>
</table>

 <table align="center"> 
 
              <tr>
          <?php
            $jjn_result_query = $conn->query("select * from organizer where organizer_id='$session_id'") or die(mysql_error());
while ($jjn_result_row = $jjn_result_query->fetch()) {
      

    ?>
            <td>
            <table>
            <tr><td align="center">&nbsp;&nbsp;&nbsp;<u><strong><?php echo $jjn_result_row['fname']." ".$jjn_result_row['mname']." ".$jjn_result_row['lname'];?></strong></u>&nbsp;&nbsp;&nbsp;</td></tr>
             <tr><td align="center">Organizer</td></tr>
            </table>
            </td>
    
           
  
<?php } ?>

</tr>
</table>

<?php }  } ?>
     
    </div>

  </div>
 
</div>


   <?php include('footer.php'); ?>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>

    <script src="assets/js/holder/holder.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>

    <script src="assets/js/application.js"></script>
 

  </body>
</html>
