 
<!DOCTYPE html>
<html lang="en">
<head>
<style>
        /* Custom card container style */
        .card {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 20px;
            width: 100vh;
            margin: 0 auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            background-color: #fff;
        }

        /* Custom card header style */
        .card-header {
            font-size: 1.5rem;
            text-align: center;
            margin-bottom: 10px;
        }

        /* Custom card content style */
        .card-body {
            font-size: 1.1rem;
            line-height: 1.4;
            margin:0px 40px
        }
    </style>
    </head>
  <?php
  error_reporting(1);
   include('header2.php');
    include('session.php');
    $contestant_ctr=$_GET['contestant_ctr'];
    $subre=$_GET['subevent_id'];
    $subresult_id=$_GET['subresult_id'];
    $subevent_id=$_GET['subevent_id'];
    $getContestant_id=$_GET['contestant_id'];
    $pageStat=$_GET['pStat'];
   
    ?>



  
  <body>

   <!-- Navbar
    ================================================== -->
    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="brand" href="#"><img src="uploads/<?php echo $company_logo; ?>" width="23" height="23" />&nbsp; <font size="3">Digital Event Judging System</font></a> 
 
          <div class="nav-collapse collapse">
            <ul class="nav">

              <li>
                <a href="contestant_panel.php"><strong>VIEW YOUR RESULTS</strong></a>
              </li>
 
                <li>
                <a href="contestant_apply_panel.php"><strong>LIST OF EVENTS</strong></a>
              </li>
 
              
 
              <li>
                <a href="contestant_login.php"><strong>LOG OUT</strong></a>
              </li>
          
            </ul>
          </div>
        </div>
      </div>
    </div>

<table style="background-color: #30475E; width: 100% !important; height: 150px; text-indent: 25px;" align="center" border="0">
<tr>
<td>
<h1 style="color: whitesmoke !important;">Contestant's Panel</h1>
<h4 style="color: whitesmoke !important;">Digital Event Judging System</h4>
</td>
</tr>
</table>

<div class="container" style="width:60%; margin-top:5vh;">
        <div class="card">
            <div class="card-header">
            <center><h4>Welcome To check your Marks, Your Details Info Are:</h4></center>
            </div>
            <hr/>
            <div class="card-body">
            <?php

if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
}?>
<?php
$conn = new mysqli("localhost", "root", "", "dejs_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$logged_in_username = $username;

$query = "SELECT c.rand_code, c.fullname, c.username, c.TotalScore, s.event_name
          FROM contestants c
          JOIN sub_event s ON c.subevent_id = s.subevent_id
          WHERE c.username = ?";

$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("s", $logged_in_username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        echo "<p class='card-text'><b>Participation Code:&nbsp;&nbsp;</b><b style='color:green'>" . $row["rand_code"] . "</b></p>";
        echo "<p class='card-text'><b>Your FullNames:&nbsp;&nbsp;</b><b style='color:green'>" . $row["fullname"] . "</b></p>";
        echo "<p class 'card-text'><b>Your UserName:&nbsp;&nbsp;</b><b style='color:green'>" . $row["username"] . "</b></p>";
       echo "<p class='card-text'><b>Sub Event Name:&nbsp;&nbsp;</b><b style='color:green'>" . $row["event_name"] . "</b></p>";
        echo "<p class='card-text'><b>Average Marks:&nbsp;&nbsp;</b><b style='color:green'>" . $row["TotalScore"] . "</b></p>";
        echo "<br>";
    }

    $stmt->close();
} else {
    echo "Failed to prepare the query.";
}

$conn->close();
?>


                </div>
            <hr/>
            <div class="card-footer">
            <center><h6 style="color:green">Thank you for patcipating in this Event.</h6></center>
            </div>
        </div>
    </div> 
                          
                          <?php include('footer.php'); ?>
                          
 
</div>
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
    <script src="assets/js/jquery.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
    <script src="assets/js/bootstrap-transition.js"></script>
    <script src="assets/js/bootstrap-alert.js"></script>
    <script src="assets/js/bootstrap-modal.js"></script>
    <script src="assets/js/bootstrap-dropdown.js"></script>
    <script src="assets/js/bootstrap-scrollspy.js"></script>
    <script src="assets/js/bootstrap-tab.js"></script>
    <script src="assets/js/bootstrap-tooltip.js"></script>
    <script src="assets/js/bootstrap-popover.js"></script>
    <script src="assets/js/bootstrap-button.js"></script>
    <script src="assets/js/bootstrap-collapse.js"></script>
    <script src="assets/js/bootstrap-carousel.js"></script>
    <script src="assets/js/bootstrap-typeahead.js"></script>
    <script src="assets/js/bootstrap-affix.js"></script>

    <script src="assets/js/holder/holder.js"></script>
    <script src="assets/js/google-code-prettify/prettify.js"></script>

    <script src="assets/js/application.js"></script>
  
  </body>
</html>
 




